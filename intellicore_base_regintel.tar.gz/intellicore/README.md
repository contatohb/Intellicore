# Intellicore
Hybrid scaffold with RegIntel 2.0/2.1.
