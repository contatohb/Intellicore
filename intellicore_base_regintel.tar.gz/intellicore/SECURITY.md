# SECURITY
Secrets via env vars; RLS on; logs in event_log.
