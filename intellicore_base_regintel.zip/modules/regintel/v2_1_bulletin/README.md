# RegIntel 2.1 Bulletin
