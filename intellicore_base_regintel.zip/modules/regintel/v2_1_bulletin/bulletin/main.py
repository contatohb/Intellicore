print('bulletin ready')
