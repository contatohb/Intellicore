print('collector ready')
