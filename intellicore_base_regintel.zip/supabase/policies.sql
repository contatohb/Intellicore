alter table registry_item enable row level security;
create policy registry_read on registry_item for select using (true);
