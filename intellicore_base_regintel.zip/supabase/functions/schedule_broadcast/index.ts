export default async function main(req: Request) { return new Response('ok'); }
