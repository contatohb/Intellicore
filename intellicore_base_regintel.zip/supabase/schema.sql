
create table if not exists registry_item (
  id uuid primary key default gen_random_uuid(),
  source text, url text, title text, summary text,
  published_at timestamptz, hash text unique, raw jsonb,
  created_at timestamptz default now()
);
